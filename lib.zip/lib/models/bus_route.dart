import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';

class BusRoute {
  final int id;
  final String name;
  final List<GeoPoint> polyline;

  BusRoute({required this.id, required this.name, required this.polyline});

  factory BusRoute.fromJson(Map<String, dynamic> json) {
    return BusRoute(
      id: json['id'],
      name: json['name'],
      polyline: (json['polyline'] as List)
          .map((p) => GeoPoint(latitude: p['lat'], longitude: p['lng']))
          .toList(),
    );
  }
}
