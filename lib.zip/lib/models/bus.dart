class Bus {
  final String busId;
  final double latitude;
  final double longitude;
  final String routeName;

  Bus(
      {required this.busId,
      required this.latitude,
      required this.longitude,
      required this.routeName});

  factory Bus.fromJson(Map<String, dynamic> json) {
    return Bus(
      busId: json['bus_id'],
      latitude: json['latitude'],
      longitude: json['longitude'],
      routeName: json['route_name'],
    );
  }
}
