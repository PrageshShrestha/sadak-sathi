class Stop {
  final String name;
  final double latitude;
  final double longitude;

  Stop({required this.name, required this.latitude, required this.longitude});

  factory Stop.fromJson(Map<String, dynamic> json) {
    return Stop(
      name: json['name'],
      latitude: json['latitude'],
      longitude: json['longitude'],
    );
  }
}
