import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../services/api_service.dart';
import 'globals.dart' as globals;

class RouteMapScreen extends StatefulWidget {
  final String routeName;

  const RouteMapScreen({super.key, required this.routeName});

  @override
  State<RouteMapScreen> createState() => _RouteMapScreenState();
}

class _RouteMapScreenState extends State<RouteMapScreen> {
  // You can add route coordinates data here after fetching from server
  List<LatLng> routeCoordinates = [];

  @override
  void initState() {
    super.initState();
    _fetchRouteDetails();
  }

  Future<void> _fetchRouteDetails() async {
    if (globals.currRouteId == null) return;

    try {
      final api = ApiService();
      // Example: fetch route polyline or stops from your API using currRouteId
      final routeDetails = await api.getRouteDetails(globals.currRouteId!);

      // Assuming routeDetails contains list of lat/lng points:
      setState(() {
        routeCoordinates = routeDetails.map<LatLng>((point) {
          return LatLng(point['lat'], point['lng']);
        }).toList();
      });
    } catch (e) {
      print('Error fetching route details: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.routeName),
      ),
      body: FlutterMap(
        options: MapOptions(
          center: LatLng(27.7172, 85.3240), // Kathmandu coords
          zoom: 13.0,
        ),
        layers: [
          TileLayerOptions(
            urlTemplate:
                "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            subdomains: ['a', 'b', 'c'],
          ),
          if (routeCoordinates.isNotEmpty)
            PolylineLayerOptions(
              polylines: [
                Polyline(
                  points: routeCoordinates,
                  strokeWidth: 4.0,
                  color: Colors.blue,
                ),
              ],
            ),
        ],
      ),
    );
  }
}
