import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../screens/globals.dart' as globals;

class AddRouteScreen extends StatefulWidget {
  const AddRouteScreen({Key? key}) : super(key: key);

  @override
  State<AddRouteScreen> createState() => _AddRouteScreenState();
}

class _AddRouteScreenState extends State<AddRouteScreen> {
  final _formKey = GlobalKey<FormState>();
  final _routeNameController = TextEditingController();
  final _coordinatesController = TextEditingController();
  final _stopsController = TextEditingController();

  String _serverResponse = '';
  bool _isLoading = false;

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
        _serverResponse = '';
      });

      try {
        final payload = {
          'routeName': _routeNameController.text,
          'coordinates': jsonDecode(_coordinatesController.text),
          'stops': _parsePythonListString(_stopsController.text),
        };

        final response = await http.post(
          Uri.parse('${globals.baseUrl}/add-route'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(payload),
        );

        setState(() {
          _isLoading = false;
          if (response.statusCode == 200) {
            final responseBody = jsonDecode(response.body);
            _serverResponse = responseBody['details'] ?? 'Route added successfully!';
            _routeNameController.clear();
            _coordinatesController.clear();
            _stopsController.clear();
          } else {
            final errorBody = jsonDecode(response.body);
            String errorMessage = 'Server error: ${response.statusCode}';
            if (errorBody['detail'] != null) {
              if (errorBody['detail'] is List && errorBody['detail'].isNotEmpty) {
                errorMessage = errorBody['detail'][0]['msg'] ?? 'Validation error.';
              } else if (errorBody['detail'] is String) {
                errorMessage = errorBody['detail'];
              }
            }
            _serverResponse = errorMessage;
          }
        });
      } catch (e) {
        setState(() {
          _isLoading = false;
          _serverResponse = 'Request failed: $e';
        });
      }
    }
  }

  List<dynamic> _parsePythonListString(String pythonListStr) {
    String jsonString = pythonListStr.replaceAll("'", '"');
    jsonString = jsonString.replaceAllMapped(RegExp(r'\(([^)]*)\)'), (match) => '[${match.group(1)}]');
    jsonString = jsonString.replaceAll(RegExp(r',\s*\]'), ']');

    try {
      return jsonDecode(jsonString);
    } catch (e) {
      throw FormatException('Invalid format for stops data: $e');
    }
  }

  @override
  void dispose() {
    _routeNameController.dispose();
    _coordinatesController.dispose();
    _stopsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add New Route')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _routeNameController,
                  decoration: const InputDecoration(labelText: 'Route Name'),
                  validator: (value) => value!.isEmpty ? 'Route name is required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _coordinatesController,
                  decoration: const InputDecoration(
                    labelText: 'Coordinates',
                    hintText: '[[lat, lon], [lat, lon], ...]',
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 5,
                  keyboardType: TextInputType.multiline,
                  validator: (value) => value!.isEmpty ? 'Coordinates are required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _stopsController,
                  decoration: const InputDecoration(
                    labelText: 'Stops',
                    hintText: "[('StopName', lat, lon, time), ...]",
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 5,
                  keyboardType: TextInputType.multiline,
                  validator: (value) => value!.isEmpty ? 'Stops are required' : null,
                ),
                const SizedBox(height: 16),
                _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : ElevatedButton(
                        onPressed: _submitForm,
                        child: const Text('Submit Route'),
                      ),
                const SizedBox(height: 16),
                Text(
                  _serverResponse.isEmpty
                      ? 'No response yet'
                      : 'Response: $_serverResponse',
                  style: const TextStyle(fontFamily: 'Courier'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
