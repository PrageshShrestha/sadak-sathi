library globals;

int? currRouteId;
const String url = '127.0.0.1:8000';
const String baseUrl = 'http://'+url;
const String wsUrl = 'ws://'+url;
