import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

import "globals.dart" as globals;

class BusMapScreen extends StatefulWidget {
  final String initialBusNumber;
  final int initialRouteId;
  final String initialRouteName;

  const BusMapScreen({
    Key? key,
    required this.initialBusNumber,
    required this.initialRouteId,
    required this.initialRouteName,
  }) : super(key: key);

  @override
  _BusMapScreenState createState() => _BusMapScreenState();
}

class _BusMapScreenState extends State<BusMapScreen> {
  late String busNumber;
  late int routeId;
  late String routeName;

  WebSocketChannel? channel;
  StreamSubscription? channelSubscription;
  Timer? reconnectTimer;

  List<LatLng> routeCoordinates = [];
  List<Marker> stopMarkers = [];
  List<Marker> otherBusMarkers = [];

  LatLng? busLocation;
  String? nextStop;
  bool routeDirection = false;

  StreamSubscription<Position>? positionStream;
  bool locationTrackingOn = false;

  int reconnectAttempt = 0;

  @override
  void initState() {
    super.initState();
    busNumber = widget.initialBusNumber;
    routeId = widget.initialRouteId;
    routeName = widget.initialRouteName;

    _requestLocationPermission();
  }

  Future<void> _requestLocationPermission() async {
    var status = await Permission.location.request();
    if (status.isGranted) {
      _startLocationTracking();
      _connectWebSocket();
      setState(() {
        locationTrackingOn = true;
      });
    } else {
      print("Location permission denied");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location permission denied')),
      );
    }
  }

  void _startLocationTracking() {
    const locationOptions = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
    );

    positionStream = Geolocator.getPositionStream(locationSettings: locationOptions)
        .listen((Position position) {
      final currentLocation = LatLng(position.latitude, position.longitude);
      setState(() {
        busLocation = currentLocation;
      });

      if (channel != null && locationTrackingOn) {
        final sendData = {
          'bus_number': busNumber,
          'route_id': routeId,
          'lat': position.latitude,
          'lon': position.longitude,
        };
        channel!.sink.add(jsonEncode(sendData));
      }
    });
  }

  void _stopLocationTracking() {
    positionStream?.cancel();
    positionStream = null;
  }

  void _connectWebSocket() {
    channelSubscription?.cancel();
    channel?.sink.close();
    reconnectTimer?.cancel();

    final uri = Uri.parse('${globals.wsUrl}/ws/bus/$busNumber');
    channel = WebSocketChannel.connect(uri);

    print("WebSocket connecting to $uri");

    channelSubscription = channel!.stream.listen(
      (message) {
        if (!mounted) return;

        print("Raw WebSocket message: $message"); // ✅ log raw message

        try {
          dynamic data;
          try {
            data = jsonDecode(message);
          } catch (_) {
            print("Warning: Received non-JSON message: $message");
            return;
          }

          print("Decoded WebSocket data: $data");

          setState(() {
            if (data['route_coordinates'] != null) {
              final coordsRaw = data['route_coordinates'];
              List coordsList;
              if (coordsRaw is String) {
                coordsList = jsonDecode(coordsRaw) as List;
              } else if (coordsRaw is List) {
                coordsList = coordsRaw;
              } else {
                coordsList = [];
              }

              routeCoordinates = coordsList.map<LatLng>((c) {
                if (c is List && c.length >= 2) {
                  return LatLng((c[0] as num).toDouble(), (c[1] as num).toDouble());
                } else if (c is Map) {
                  return LatLng((c['lat'] as num).toDouble(), (c['lon'] as num).toDouble());
                }
                return const LatLng(0, 0);
              }).toList();
            }

            if (data['stops'] != null) {
              final stopsRaw = data['stops'];
              List stopsList;
              if (stopsRaw is String) {
                stopsList = jsonDecode(stopsRaw) as List;
              } else if (stopsRaw is List) {
                stopsList = stopsRaw;
              } else {
                stopsList = [];
              }

              stopMarkers = stopsList.map<Marker>((stop) {
                if (stop is List && stop.length >= 3) {
                  final stopLat = (stop[1] as num).toDouble();
                  final stopLon = (stop[2] as num).toDouble();
                  return Marker(
                    point: LatLng(stopLat, stopLon),
                    width: 30,
                    height: 30,
                    child: const Icon(Icons.location_on, color: Colors.blue),
                  );
                } else if (stop is Map) {
                  final stopLat = (stop['lat'] as num).toDouble();
                  final stopLon = (stop['lon'] as num).toDouble();
                  return Marker(
                    point: LatLng(stopLat, stopLon),
                    width: 30,
                    height: 30,
                    child: const Icon(Icons.location_on, color: Colors.blue),
                  );
                }
                return const Marker(
                  point: LatLng(0, 0),
                  width: 30,
                  height: 30,
                  child: Icon(Icons.error, color: Colors.red),
                );
              }).toList();
            }

            if (data['other_buses'] != null) {
              List otherBusesList;
              if (data['other_buses'] is String) {
                otherBusesList = jsonDecode(data['other_buses']);
              } else if (data['other_buses'] is List) {
                otherBusesList = data['other_buses'];
              } else {
                otherBusesList = [];
              }

              otherBusMarkers = otherBusesList.map<Marker>((bus) {
                final busLat = (bus['lat'] as num).toDouble();
                final busLon = (bus['lon'] as num).toDouble();
                return Marker(
                  point: LatLng(busLat, busLon),
                  width: 30,
                  height: 30,
                  child: const Icon(Icons.directions_bus, color: Colors.red),
                );
              }).toList();
            }

            if (data['bus_location'] != null) {
              final loc = data['bus_location'];
              busLocation = LatLng(
                  (loc['lat'] as num).toDouble(), (loc['lon'] as num).toDouble());
              nextStop = loc['next_stop'];
              routeDirection = loc['route_direction'] ?? false;
            }

            if (data['route_name'] != null) {
              routeName = data['route_name'];
            }
          });
        } catch (e) {
          print("Error parsing WebSocket message: $e");
        }
      },
      onDone: () {
        if (mounted) {
          print("WebSocket connection closed. Scheduling reconnect...");
          _scheduleReconnect();
        }
      },
      onError: (error) {
        print("WebSocket error: $error");
        if (mounted) {
          _scheduleReconnect();
        }
      },
      cancelOnError: true,
    );
  }

  void _scheduleReconnect() {
    reconnectAttempt++;
    final delaySeconds = (3 * reconnectAttempt).clamp(3, 30);

    reconnectTimer = Timer(Duration(seconds: delaySeconds), () {
      if (mounted) {
        print("Attempting to reconnect WebSocket (attempt #$reconnectAttempt)");
        _connectWebSocket();
      }
    });
  }

  Future<void> _toggleLocationTracking() async {
    if (locationTrackingOn) {
      final result = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Turn off location?'),
          content: const Text('Please don\'t turn off location while on the ride.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Turn Off'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
          ],
        ),
      );

      if (result == true) {
        _stopLocationTracking();
        channel?.sink.close();
        setState(() {
          locationTrackingOn = false;
        });
      }
    } else {
      var status = await Permission.location.status;
      if (!status.isGranted) {
        status = await Permission.location.request();
      }
      if (status.isGranted) {
        _startLocationTracking();
        _connectWebSocket();
        setState(() {
          locationTrackingOn = true;
          reconnectAttempt = 0;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Location permission denied')),
        );
      }
    }
  }

  @override
  void dispose() {
    channelSubscription?.cancel();
    channel?.sink.close();
    reconnectTimer?.cancel();
    positionStream?.cancel();
    super.dispose();
  }

  void _openSettingsDialog() {
    final routeNameController = TextEditingController(text: routeName);
    final routeIdController = TextEditingController(text: routeId.toString());

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Route Info'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: routeNameController,
              decoration: const InputDecoration(labelText: 'Route Name'),
            ),
            TextField(
              controller: routeIdController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Route ID'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                routeName = routeNameController.text;
                routeId = int.tryParse(routeIdController.text) ?? routeId;
              });
              Navigator.of(context).pop();
            },
            child: const Text('Save'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  Widget _buildMap() {
    return FlutterMap(
      options: MapOptions(
        initialCenter: busLocation ?? LatLng(27.7172, 85.3240),
        initialZoom: 13.0,
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        ),
        if (routeCoordinates.isNotEmpty)
          PolylineLayer(
            polylines: [
              Polyline(
                points: routeCoordinates,
                strokeWidth: 4,
                color: Colors.blue,
              ),
            ],
          ),
        MarkerLayer(
          markers: [
            ...stopMarkers,
            ...otherBusMarkers,
            if (busLocation != null)
              Marker(
                point: busLocation!,
                width: 30,
                height: 30,
                child: const Icon(Icons.directions_bus, color: Colors.green),
              ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bus Route & Location'),
        actions: [
          IconButton(
            icon: Icon(locationTrackingOn ? Icons.location_on : Icons.location_off),
            tooltip: locationTrackingOn ? 'Turn off location' : 'Turn on location',
            onPressed: _toggleLocationTracking,
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _openSettingsDialog,
          )
        ],
      ),
      body: Column(
        children: [
          if (!locationTrackingOn || channel == null)
            Container(
              width: double.infinity,
              color: Colors.redAccent,
              padding: const EdgeInsets.all(8),
              child: const Text(
                'Disconnected from server, reconnecting...',
                style: TextStyle(color: Colors.white),
                textAlign: TextAlign.center,
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              'Route: $routeName (ID: $routeId)',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(child: _buildMap()),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Column(
              children: [
                Text('Bus Number: $busNumber'),
                Text('Next Stop: ${nextStop ?? 'Loading...'}'),
                Text('Route Direction: ${routeDirection ? "Opposite" : "Actual"}'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
