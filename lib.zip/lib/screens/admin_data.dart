import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'globals.dart' as globals;

class AdminDataPanel extends StatefulWidget {
  const AdminDataPanel({Key? key}) : super(key: key);

  @override
  State<AdminDataPanel> createState() => _AdminDataPanelState();
}

class _AdminDataPanelState extends State<AdminDataPanel> {
  Map<String, List<Map<String, dynamic>>> allData = {};
  bool loading = true;
  String errorMessage = "";
  String statusMessage = "";

  @override
  void initState() {
    super.initState();
    fetchAllData();
  }

  Future<void> fetchAllData() async {
    setState(() {
      loading = true;
      errorMessage = "";
      statusMessage = "";
    });
    try {
      final response = await http.post(
        Uri.parse("${globals.baseUrl}/get-all-data"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        Map<String, List<Map<String, dynamic>>> parsedData = {};

        for (var entry in data.entries) {
          if (entry.value is List) {
            final list = entry.value as List;
            if (list.isNotEmpty && list.first is Map<String, dynamic>) {
              parsedData[entry.key] = List<Map<String, dynamic>>.from(
                list.map((e) => Map<String, dynamic>.from(e)),
              );
            } else if (list.isEmpty) {
              parsedData[entry.key] = [];
            }
          }
        }

        setState(() {
          allData = parsedData;
          loading = false;
        });
      } else {
        setState(() {
          errorMessage = "Failed to fetch data: ${response.statusCode}";
          loading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Error fetching data: $e";
        loading = false;
      });
    }
  }

  Future<void> showEditDialog(String table, Map<String, dynamic> row) async {
    final primaryKeys = ['id', 'bus_number', 'route_id'];

    final controllers = {
      for (var key in row.keys)
        if (!(key.toLowerCase().contains("time") ||
            key.toLowerCase().contains("date") ||
            primaryKeys.contains(key)))
          key: TextEditingController(text: row[key]?.toString() ?? "")
    };

    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit $table Row'),
          content: SingleChildScrollView(
            child: Column(
              children: controllers.entries.map((entry) {
                return TextField(
                  controller: entry.value,
                  decoration: InputDecoration(labelText: entry.key),
                );
              }).toList(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () async {
                final updates = <String, dynamic>{};
                for (var entry in controllers.entries) {
                  final key = entry.key;
                  final newValue = entry.value.text;
                  if (newValue != row[key]?.toString()) {
                    updates[key] = newValue;
                  }
                }

                if (updates.isNotEmpty) {
                  final idKey = row.keys.first;
                  final identifier = {idKey: row[idKey]};
                  final body = jsonEncode({
                    "table": table,
                    "identifier": identifier,
                    "updates": updates,
                  });

                  final res = await http.post(
                    Uri.parse("${globals.baseUrl}/update-row"),
                    headers: {'Content-Type': 'application/json'},
                    body: body,
                  );

                  if (res.statusCode == 200) {
                    Navigator.pop(context);
                    setState(() => statusMessage = "✅ Row updated successfully.");
                    await fetchAllData();
                  } else {
                    setState(() => statusMessage = "❌ Error updating row.");
                  }
                } else {
                  setState(() => statusMessage = "⚠️ No changes made.");
                  Navigator.pop(context);
                }
              },
              child: const Text("Save"),
            )
          ],
        );
      },
    );
  }

  Widget buildTable(String title, List<Map<String, dynamic>> rows) {
    if (rows.isEmpty) return Text("No data in $title");

    final filteredHeaders = rows.first.keys
        .where((k) =>
            !(k.toLowerCase().contains("time") || k.toLowerCase().contains("date")))
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10.0),
          child: Text(
            "$title (${rows.length})",
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columnSpacing: 20,
            columns: filteredHeaders
                .map((header) => DataColumn(
                    label:
                        Text(header, style: const TextStyle(fontWeight: FontWeight.bold))))
                .toList(),
            rows: rows
                .map((row) => DataRow(
                      cells: filteredHeaders
                          .map((header) => DataCell(
                                Text(row[header]?.toString() ?? ''),
                                onTap: () => showEditDialog(title, row),
                              ))
                          .toList(),
                    ))
                .toList(),
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget buildSummaryStats() {
    final totalBuses = allData['bus_info']?.length ?? 0;
    final totalRoutes = allData['route_info']?.length ?? 0;
    final totalUsers = allData['users']?.length ?? 0;
    final totalAuthorized = allData['user_authorized']
            ?.where((u) => u['authorized'].toString() == 'true')
            .length ??
        0;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 12),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Wrap(
          spacing: 20,
          runSpacing: 10,
          children: [
            Text("🚌 Total Buses: $totalBuses",
                style: const TextStyle(fontSize: 16)),
            Text("🗺️ Total Routes: $totalRoutes",
                style: const TextStyle(fontSize: 16)),
            Text("👤 Registered Users: $totalUsers",
                style: const TextStyle(fontSize: 16)),
            Text("✅ Authorized Users: $totalAuthorized",
                style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Panel - Sadak Sathi")),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage.isNotEmpty
              ? Center(child: Text(errorMessage))
              : RefreshIndicator(
                  onRefresh: fetchAllData,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (statusMessage.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Text(statusMessage,
                              style: const TextStyle(color: Colors.green)),
                        ),

                      // *** ADDED BUTTONS ROW ***
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton.icon(
                              icon: const Icon(Icons.add_location),
                              label: const Text("Add Route"),
                              style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 12, horizontal: 18)),
                              onPressed: () {
                                Navigator.pushNamed(context, '/admin_1');
                              },
                            ),
                            const SizedBox(width: 12),
                            ElevatedButton.icon(
                              icon: const Icon(Icons.directions_bus),
                              label: const Text("Add Bus"),
                              style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 12, horizontal: 18)),
                              onPressed: () {
                                Navigator.pushNamed(context, '/admin_2');
                              },
                            ),
                          ],
                        ),
                      ),

                      buildSummaryStats(),
                      ...allData.entries.map((e) => buildTable(e.key, e.value)).toList(),
                    ],
                  ),
                ),
    );
  }
}
