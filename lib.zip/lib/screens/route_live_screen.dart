// screens/route_live_screen.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class RoutesScreen extends StatefulWidget {
  const RoutesScreen({Key? key}) : super(key: key);

  @override
  State<RoutesScreen> createState() => _RoutesScreenState();
}

class _RoutesScreenState extends State<RoutesScreen> {
  late WebSocketChannel channel;

  List<LatLng> routeCoordinates = [];
  List<LatLng> busLocations = [];
  List<String> busNumbers = [];

  final String routeName = "demo_route"; // change to the one you want
  final String baseUrl = "ws://127.0.0.1:8000"; // change to your backend's IP/host

  @override
  void initState() {
    super.initState();
    _connectWebSocket();
  }

  void _connectWebSocket() {
    final url = "$baseUrl/ws/$routeName";
    channel = WebSocketChannel.connect(Uri.parse(url));

    channel.stream.listen((message) {
      final data = jsonDecode(message);
      final echo = data["echo"];

      final List routeCoords = echo["route_coordinates"];
      final List routeBuses = echo["bus_list"];

      setState(() {
        routeCoordinates = routeCoords
            .map<LatLng>((coord) => LatLng(coord[0], coord[1]))
            .toList();

        busLocations = routeBuses
            .map<LatLng>((bus) => LatLng(bus[1], bus[2]))
            .toList();

        busNumbers = routeBuses.map<String>((bus) => bus[0].toString()).toList();
      });
    });
  }

  @override
  void dispose() {
    channel.sink.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Live Route View: $routeName')),
      body: FlutterMap(
        options: MapOptions(
          center: LatLng(27.7172, 85.3240), // Kathmandu
          zoom: 13.0,
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.sadaksathi.app',
          ),
          PolylineLayer(
            polylines: [
              Polyline(
                points: routeCoordinates,
                strokeWidth: 4.0,
                color: Colors.blue,
              ),
            ],
          ),
          MarkerLayer(
            markers: [
              for (int i = 0; i < busLocations.length; i++)
                Marker(
                  width: 80,
                  height: 80,
                  point: busLocations[i],
                  builder: (ctx) => Column(
                    children: [
                      const Icon(Icons.directions_bus, color: Colors.red),
                      Text(busNumbers[i], style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
