import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'globals.dart' as globals;

class AddBusScreen extends StatefulWidget {
  const AddBusScreen({Key? key}) : super(key: key);

  @override
  State<AddBusScreen> createState() => _AddBusScreenState();
}

class _AddBusScreenState extends State<AddBusScreen> {
  final _formKey = GlobalKey<FormState>();
  final _busNumberController = TextEditingController();
  final _routeIdController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isLoading = false;
  String _serverResponse = '';
  bool _obscurePassword = true;

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
        _serverResponse = '';
      });

      final payload = {
        'bus_number': _busNumberController.text.trim(),
        'route_id': int.parse(_routeIdController.text.trim()),
        'password': _passwordController.text.trim(),
      };

      try {
        final response = await http.post(
          Uri.parse('${globals.baseUrl}/add_bus'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(payload),
        );

        setState(() {
          _isLoading = false;
          if (response.statusCode == 200) {
            final responseBody = jsonDecode(response.body);
            _serverResponse = responseBody['details'] ?? 'Success';
          } else {
            _serverResponse = 'Server error: ${response.statusCode}';
          }
        });
      } catch (e) {
        setState(() {
          _isLoading = false;
          _serverResponse = 'Request failed: $e';
        });
      }
    }
  }

  @override
  void dispose() {
    _busNumberController.dispose();
    _routeIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add New Bus')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  controller: _busNumberController,
                  decoration: const InputDecoration(
                    labelText: 'Bus Number',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.directions_bus),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Bus number is required';
                    }
                    return null;
                  },
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(height: 18),
                TextFormField(
                  controller: _routeIdController,
                  decoration: const InputDecoration(
                    labelText: 'Route ID',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.route),
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Route ID is required';
                    }
                    if (int.tryParse(value.trim()) == null) {
                      return 'Route ID must be a valid number';
                    }
                    return null;
                  },
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(height: 18),
                TextFormField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: 'Bus Password',
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(Icons.lock),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePassword ? Icons.visibility : Icons.visibility_off,
                      ),
                      onPressed: () {
                        setState(() {
                          _obscurePassword = !_obscurePassword;
                        });
                      },
                    ),
                  ),
                  obscureText: _obscurePassword,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Bus password is required';
                    }
                    return null;
                  },
                  onFieldSubmitted: (_) => _submitForm(),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _submitForm,
                    child: _isLoading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Text('Submit Bus'),
                  ),
                ),
                const SizedBox(height: 24),
                if (_serverResponse.isNotEmpty)
                  Text(
                    _serverResponse,
                    style: TextStyle(
                      fontFamily: 'Courier',
                      fontWeight: FontWeight.bold,
                      color: _serverResponse.toLowerCase().contains('error') ? Colors.red : Colors.green[700],
                    ),
                    textAlign: TextAlign.center,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
