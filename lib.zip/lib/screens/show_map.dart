import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_map_cancellable_tile_provider/flutter_map_cancellable_tile_provider.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' show Distance;

import 'globals.dart' as globals;

class ShowMapScreen extends StatefulWidget {
  final int routeId;
  final String routeName;

  const ShowMapScreen({
    Key? key,
    required this.routeId,
    required this.routeName,
  }) : super(key: key);

  @override
  State<ShowMapScreen> createState() => _ShowMapScreenState();
}

class _ShowMapScreenState extends State<ShowMapScreen> {
  late final WebSocketChannel channel;
  late final MapController _mapController;

  List<LatLng> routeCoordinates = [const LatLng(27.6162, 85.5393)];
  List<Map<String, dynamic>> routeStops = [];
  List<Map<String, dynamic>> buses = [];

  bool _initialCentered = false;
  LatLng? userLocation;
  bool _isLocationServiceEnabled = false;

  Map<String, dynamic>? selectedBus;

  List<LatLng> _routeToNearestStop = [];
  List<LatLng> _routeToNearestRoutePoint = [];
  bool _showShortestRoute = false;
  String? _nearestStopName; // New field to store nearest stop name

  Map<String, dynamic>? _currentOpenStop;
  Map<String, dynamic>? _currentOpenBus;
  StateSetter? _stopBottomSheetSetState;
  StateSetter? _busBottomSheetSetState;

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
    _checkAndGetLocationStatus();
    _getCachedUserLocation();
    _initLocation();
    channel = WebSocketChannel.connect(
      Uri.parse('${globals.wsUrl}/ws/route_id/${widget.routeId}'),
    );

    channel.stream.listen(
      (message) {
        final data = json.decode(message);
        final echo = data['echo'];

        if (echo != null) {
          final coords = echo['route_coordinates'] as List;
          final stops = echo['route_stops'] as List;
          final busList = echo['bus_list'] as List;

          setState(() {
            routeCoordinates = coords
                .map((coord) => LatLng(coord[1], coord[0]))
                .toList();

            routeStops = stops.map((stop) {
              return {
                "name": stop['name'],
                "latlng": LatLng(stop['lat'], stop['lon']),
                "order": stop['order'],
              };
            }).toList();

            buses = busList.map((bus) {
              return {
                "bus_number": bus['bus_number'],
                "latlng": (bus['lat'] != null && bus['lon'] != null)
                    ? LatLng(bus['lat'], bus['lon'])
                    : null,
                "eta": bus['eta'],
                "next_stop": bus['next_stop'],
                "speed": bus['speed'],
                "time_stop": bus['time_stop'],
              };
            }).toList();

            if (!_initialCentered && routeCoordinates.isNotEmpty) {
              final bounds = LatLngBounds.fromPoints(routeCoordinates);
              _mapController.fitCamera(
                CameraFit.bounds(
                  bounds: bounds,
                  padding: const EdgeInsets.all(50),
                ),
              );
              _initialCentered = true;
            }
          });

          if (_currentOpenStop != null && _stopBottomSheetSetState != null) {
            final updatedStop = routeStops.firstWhere(
              (stop) => stop['name'] == _currentOpenStop!['name'],
              orElse: () => _currentOpenStop!,
            );
            _currentOpenStop = updatedStop;
            _stopBottomSheetSetState!(() {});
          }

          if (_currentOpenBus != null && _busBottomSheetSetState != null) {
            final updatedBus = buses.firstWhere(
              (bus) => bus['bus_number'] == _currentOpenBus!['bus_number'],
              orElse: () => _currentOpenBus!,
            );
            _currentOpenBus = updatedBus;
            _busBottomSheetSetState!(() {});
          }
        }
      },
      onError: (error) {
        print("WebSocket error: $error");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("WebSocket error: $error")),
        );
      },
      onDone: () {
        print("WebSocket connection closed");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("WebSocket connection closed")),
        );
      },
    );
  }

  Future<void> _checkAndGetLocationStatus() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    setState(() {
      _isLocationServiceEnabled = serviceEnabled;
    });
  }

  Future<void> _initLocation() async {
    final status = await Permission.location.request();
    if (status.isGranted) {
      _checkAndGetLocationStatus();
      try {
        final position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        );
        setState(() {
          userLocation = LatLng(position.latitude, position.longitude);
        });
        final prefs = await SharedPreferences.getInstance();
        await prefs.setDouble('user_lat', position.latitude);
        await prefs.setDouble('user_lon', position.longitude);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Could not get current location: $e")),
        );
        setState(() {
          userLocation = null;
        });
      }
    } else {
      setState(() {
        userLocation = null;
        _isLocationServiceEnabled = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Location permission denied.")),
      );
    }
  }

  Future<void> _getCachedUserLocation() async {
    final prefs = await SharedPreferences.getInstance();
    final lat = prefs.getDouble('user_lat');
    final lon = prefs.getDouble('user_lon');
    if (lat != null && lon != null) {
      setState(() {
        userLocation = LatLng(lat, lon);
      });
    }
  }

  void _recenterMap() {
    if (routeCoordinates.isNotEmpty) {
      final bounds = LatLngBounds.fromPoints(routeCoordinates);
      _mapController.fitCamera(
        CameraFit.bounds(
          bounds: bounds,
          padding: const EdgeInsets.all(50),
        ),
      );
    }
  }

  List<LatLng> _getDottedPolyline(List<LatLng> points, double dashLength, double gapLength) {
    if (points.length < 2) return [];

    List<LatLng> dottedPoints = [];
    final distanceCalculator = const Distance();

    for (int i = 0; i < points.length - 1; i++) {
      LatLng p1 = points[i];
      LatLng p2 = points[i + 1];

      double distance = distanceCalculator.as(
        LengthUnit.Meter,
        p1,
        p2,
      );
      int numberOfSegments = (distance / (dashLength + gapLength)).ceil();

      for (int j = 0; j < numberOfSegments; j++) {
        double startFraction = (j * (dashLength + gapLength)) / distance;
        double endFraction = (j * (dashLength + gapLength) + dashLength) / distance;

        if (startFraction < 1.0) {
          double lat1 = p1.latitude + (p2.latitude - p1.latitude) * startFraction;
          double lon1 = p1.longitude + (p2.longitude - p1.longitude) * startFraction;
          dottedPoints.add(LatLng(lat1, lon1));
        }

        if (endFraction < 1.0) {
          double lat2 = p1.latitude + (p2.latitude - p1.latitude) * endFraction;
          double lon2 = p1.longitude + (p2.longitude - p1.longitude) * endFraction;
          dottedPoints.add(LatLng(lat2, lon2));
        }
      }
    }
    return dottedPoints;
  }

  Future<void> _fetchShortestRoute(String stopName) async {
    if (userLocation == null) {
      await _initLocation();
      if (userLocation == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please enable location services and grant permission to find the shortest path.")),
        );
        return;
      }
    }

    try {
      const int vehicleType = 1; // Walking mode
      final response = await http.post(
        Uri.parse('${globals.baseUrl}/shortest_route'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'user_lat': userLocation!.latitude,
          'user_lon': userLocation!.longitude,
          'vehicle': vehicleType,
          'route_id': widget.routeId.toString(),
        }),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data.containsKey("details")) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data["details"])),
          );
          return;
        }

        List<LatLng> route1Coords = (data['route'] as List)
            .map((coord) => LatLng(coord[1], coord[0]))
            .toList();
        List<LatLng> route2Coords = (data['route_1'] as List)
            .map((coord) => LatLng(coord[1], coord[0]))
            .toList();

        setState(() {
          _routeToNearestStop = route1Coords;
          _routeToNearestRoutePoint = route2Coords;
          _showShortestRoute = true;
          _nearestStopName = data['nearest_stop']; // Store the nearest stop name
          final allRoutePoints = [..._routeToNearestStop, ..._routeToNearestRoutePoint];
          if (allRoutePoints.isNotEmpty) {
            final bounds = LatLngBounds.fromPoints(allRoutePoints);
            _mapController.fitCamera(
              CameraFit.bounds(
                bounds: bounds,
                padding: const EdgeInsets.all(50),
              ),
            );
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to fetch shortest route: ${response.statusCode}")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching shortest route: $e")),
      );
    }
  }

  void _clearShortestRoute() {
    setState(() {
      _routeToNearestStop = [];
      _routeToNearestRoutePoint = [];
      _showShortestRoute = false;
      _nearestStopName = null; // Clear the nearest stop name
      _recenterMap();
    });
  }

  void _showStopInfo(Map<String, dynamic> stop) {
  _currentOpenStop = stop;
  _stopBottomSheetSetState = null;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (BuildContext context) {
      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setStateInBottomSheet) {
          _stopBottomSheetSetState = setStateInBottomSheet;

          // Corrected: Assign busesAtStop directly without erroneous 'busestroppo'
          List<Map<String, dynamic>> busesAtStop = buses.where((bus) {
            return bus['next_stop'] != null &&
                bus['next_stop'].toString().toLowerCase() ==
                    _currentOpenStop!['name'].toString().toLowerCase();
          }).toList();

          busesAtStop.sort((a, b) {
            if (a['eta'] == null) return 1;
            if (b['eta'] == null) return -1;
            return (a['eta'] as num).compareTo(b['eta'] as num);
          });

          String nextBusText = "No upcoming buses";
          if (busesAtStop.isNotEmpty && busesAtStop[0]['eta'] != null) {
            nextBusText = "Next bus: #${busesAtStop[0]['bus_number']}, ETA: ${busesAtStop[0]['eta'].toString()} sec";
          }

          return FractionallySizedBox(
            heightFactor: 0.30,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _currentOpenStop!['name'],
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    nextBusText,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: Colors.green,
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    "Buses at this stop:",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: busesAtStop.isEmpty
                        ? const Text(
                            "No buses currently heading to this stop.",
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          )
                        : ListView.builder(
                            itemCount: busesAtStop.length,
                            itemBuilder: (context, index) {
                              final bus = busesAtStop[index];
                              return ListTile(
                                contentPadding: EdgeInsets.zero,
                                title: Text(
                                  "Bus #${bus['bus_number']}",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "ETA: ${bus['eta'] != null ? bus['eta'].toString() + ' sec' : 'Unknown'}",
                                      style: const TextStyle(fontSize: 14),
                                    ),
                                    Text(
                                      "Speed: ${bus['speed'] != null ? (bus['speed'] as num).toStringAsFixed(1) + ' km/h' : 'Unknown'}",
                                      style: const TextStyle(fontSize: 14),
                                    ),
                                    Text(
                                      "Waiting Time: ${bus['time_stop'] != null ? bus['time_stop'].toString() + ' sec' : 'N/A'}",
                                      style: const TextStyle(fontSize: 14),
                                    ),
                                  ],
                                ),
                                onTap: () {
                                  Navigator.pop(context);
                                  _currentOpenStop = null;
                                  _stopBottomSheetSetState = null;
                                  _focusOnBus(bus);
                                },
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade600,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 3,
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                        _currentOpenStop = null;
                        _stopBottomSheetSetState = null;
                        _fetchShortestRoute(stop['name']);
                      },
                      child: const Text(
                        "See path from my location",
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  ).whenComplete(() {
    _currentOpenStop = null;
    _stopBottomSheetSetState = null;
  });
}

  void _showBusInfo(Map<String, dynamic> bus) {
    _currentOpenBus = bus;
    _busBottomSheetSetState = null;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setStateInBottomSheet) {
            _busBottomSheetSetState = setStateInBottomSheet;

            final currentBusData = buses.firstWhere(
              (b) => b['bus_number'] == _currentOpenBus!['bus_number'],
              orElse: () => _currentOpenBus!,
            );

            return FractionallySizedBox(
              heightFactor: 0.30,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Bus #${currentBusData['bus_number']}",
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        Icon(
                          Icons.directions_bus,
                          color: Colors.green.shade700,
                          size: 30,
                        ),
                      ],
                    ),
                    const Divider(height: 25, thickness: 1),
                    _buildBusDetailRow("Next Stop:", currentBusData['next_stop'] ?? 'Unknown'),
                    _buildBusDetailRow("ETA:", currentBusData['eta'] != null ? '${currentBusData['eta']} seconds' : 'Unknown'),
                    _buildBusDetailRow("Speed:", currentBusData['speed'] != null ? '${(currentBusData['speed'] as num).toStringAsFixed(1)} km/h' : 'Unknown'),
                    _buildBusDetailRow("Waiting Time:", currentBusData['time_stop'] != null ? '${currentBusData['time_stop']} seconds' : 'N/A'),
                    const Spacer(),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green.shade600,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 3,
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                          _currentOpenBus = null;
                          _busBottomSheetSetState = null;
                          setState(() {
                            selectedBus = currentBusData;
                          });
                        },
                        child: const Text(
                          "Show Route Remaining",
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      _currentOpenBus = null;
      _busBottomSheetSetState = null;
    });
  }

  Widget _buildBusDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(fontSize: 16, color: Colors.grey[700]),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  void _focusOnBus(Map<String, dynamic> bus) {
    setState(() {
      selectedBus = bus;
    });
    if (bus['latlng'] != null) {
      _mapController.move(bus['latlng'], 17);
    }
  }

  @override
  void dispose() {
    channel.sink.close();
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    LatLng initialCenter = routeCoordinates.isNotEmpty
        ? routeCoordinates[routeCoordinates.length ~/ 2]
        : const LatLng(28.3949, 84.1240);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.routeName),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: initialCenter,
              initialZoom: 15,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                tileProvider: CancellableNetworkTileProvider(),
                userAgentPackageName: 'com.example.yourapp',
              ),
              if (routeCoordinates.length > 1)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: routeCoordinates,
                      strokeWidth: 4,
                      color: Colors.blue.shade700,
                    ),
                  ],
                ),
              if (_showShortestRoute && _routeToNearestStop.isNotEmpty)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: _routeToNearestStop,
                      strokeWidth: 4,
                      color: Colors.orange.shade600,
                    ),
                  ],
                ),
              if (_showShortestRoute && _routeToNearestRoutePoint.isNotEmpty)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: _getDottedPolyline(_routeToNearestRoutePoint, 8, 8),
                      strokeWidth: 3,
                      color: Colors.blue.shade600,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: routeStops.map((stop) {
                  return Marker(
                    width: 40,
                    height: 40,
                    point: stop["latlng"],
                    child: GestureDetector(
                      onTap: () => _showStopInfo(stop),
                      child: const Icon(
                        Icons.location_pin,
                        color: Colors.red,
                        size: 30,
                      ),
                    ),
                  );
                }).toList(),
              ),
              MarkerLayer(
                markers: buses.where((bus) => bus['latlng'] != null).map((bus) {
                  return Marker(
                    width: 40,
                    height: 40,
                    point: bus["latlng"],
                    child: GestureDetector(
                      onTap: () => _showBusInfo(bus),
                      child: Icon(
                        Icons.directions_bus,
                        color: (selectedBus != null && selectedBus!['bus_number'] == bus['bus_number'])
                            ? Colors.orange.shade600
                            : Colors.green.shade700,
                        size: 30,
                      ),
                    ),
                  );
                }).toList(),
              ),
              if (userLocation != null)
                MarkerLayer(
                  markers: [
                    Marker(
                      point: userLocation!,
                      width: 40,
                      height: 40,
                      child: const Icon(
                        Icons.person_pin_circle,
                        color: Colors.blue,
                        size: 30,
                      ),
                    ),
                  ],
                ),
            ],
          ),
          Positioned(
            top: 16,
            right: 16,
            child: FloatingActionButton(
              heroTag: 'recenterBtn',
              onPressed: _recenterMap,
              backgroundColor: Colors.blue.shade700,
              elevation: 3,
              child: const Icon(Icons.my_location, color: Colors.white),
            ),
          ),
          Positioned(
            bottom: 16,
            right: 16,
            child: FloatingActionButton(
              heroTag: 'locationBtn',
              onPressed: () async {
                await _initLocation();
                if (userLocation != null) {
                  _mapController.move(userLocation!, 17);
                }
              },
              backgroundColor: _isLocationServiceEnabled && userLocation != null
                  ? Colors.green.shade600
                  : Colors.grey.shade600,
              elevation: 3,
              child: Icon(
                _isLocationServiceEnabled && userLocation != null
                    ? Icons.gps_fixed
                    : Icons.gps_off,
                color: Colors.white,
              ),
            ),
          ),
          if (_showShortestRoute)
            Positioned(
              top: 80,
              right: 16,
              child: FloatingActionButton(
                heroTag: 'clearRouteBtn',
                onPressed: _clearShortestRoute,
                backgroundColor: Colors.red.shade600,
                elevation: 3,
                child: const Icon(Icons.clear, color: Colors.white),
              ),
            ),
          if (_showShortestRoute && _nearestStopName != null)
            Positioned(
              bottom: 80,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Text(
                  "Nearest Stop: $_nearestStopName",
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
        ],
      ),
    );
  }
}