// lib/screens/admin_panel.dart
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' as latlng;
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';
import 'dart:convert';

class AdminPanel extends StatefulWidget {
  @override
  _AdminPanelState createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  final _routeNameController = TextEditingController();
  final _polylineController = TextEditingController();
  final _busIdController = TextEditingController();
  final _routeIdController = TextEditingController();
  final _capacityController = TextEditingController();
  final _stopRouteIdController = TextEditingController();
  late ApiService _apiService;
  List<Map<String, dynamic>> _routes = [];
  List<Map<String, dynamic>> _buses = [];
  List<Map<String, dynamic>> _stops = [];
  List<Polyline> _polylines = [];
  List<Marker> _markers = [];

  @override
  void initState() {
    super.initState();
    _apiService = ApiService(
        token: Provider.of<AuthProvider>(context, listen: false).token);
    _fetchRoutes();
    _fetchBuses();
  }

  Future<void> _fetchRoutes() async {
    try {
      final routes = await _apiService.getRoutes();
      setState(() {
        _routes = routes;
        _updatePolylines();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load routes: $e')),
      );
    }
  }

  Future<void> _fetchBuses() async {
    try {
      final buses = await _apiService.getBuses();
      setState(() {
        _buses = buses;
        _updateMarkers();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load buses: $e')),
      );
    }
  }

  Future<void> _fetchStops() async {
    if (_stopRouteIdController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a Route ID')),
      );
      return;
    }
    try {
      final routeId = int.parse(_stopRouteIdController.text);
      final stops = await _apiService.getStops(routeId);
      setState(() {
        _stops = stops;
        _updateMarkers();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Stops loaded: ${stops.length}')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load stops: $e')),
      );
    }
  }

  void _updatePolylines() {
    List<Polyline> polylines = [];
    for (var route in _routes) {
      final List<dynamic> polylineData = route['polyline'];
      final List<latlng.LatLng> points = polylineData
          .map((point) => latlng.LatLng(point['lat'], point['lng']))
          .toList();
      polylines.add(
        Polyline(
          points: points,
          strokeWidth: 4.0,
          color: Colors.blue,
        ),
      );
    }
    setState(() {
      _polylines = polylines;
    });
  }

  void _updateMarkers() {
    List<Marker> markers = [];
    // Add bus markers
    for (var bus in _buses) {
      if (bus['latitude'] != null && bus['longitude'] != null) {
        markers.add(
          Marker(
            point: latlng.LatLng(bus['latitude'], bus['longitude']),
            width: 40,
            height: 40,
            child:
                const Icon(Icons.directions_bus, color: Colors.red, size: 30),
          ),
        );
      }
    }
    // Add stop markers
    for (var stop in _stops) {
      markers.add(
        Marker(
          point: latlng.LatLng(stop['latitude'], stop['longitude']),
          width: 40,
          height: 40,
          child: const Icon(Icons.location_on, color: Colors.green, size: 30),
        ),
      );
    }
    setState(() {
      _markers = markers;
    });
  }

  Future<void> _addRoute() async {
    if (_routeNameController.text.isEmpty || _polylineController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    try {
      final polylineData = jsonDecode(_polylineController.text) as List;
      final List<Map<String, double>> polyline = polylineData
          .map((point) => {
                'lat': (point['lat'] as num).toDouble(),
                'lng': (point['lng'] as num).toDouble(),
              })
          .toList();
      final response = await _apiService.addRoute(
        _routeNameController.text,
        polyline,
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Route added successfully: ${response['name']}')),
      );
      _fetchRoutes();
      _routeNameController.clear();
      _polylineController.clear();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to add route: $e')),
      );
    }
  }

  Future<void> _addBus() async {
    if (_busIdController.text.isEmpty || _capacityController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    try {
      final routeId = _routeIdController.text.isEmpty
          ? null
          : int.parse(_routeIdController.text);
      final response = await _apiService.addBus(
        _busIdController.text,
        routeId,
        int.parse(_capacityController.text),
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Bus added successfully: ${response['bus_id']}')),
      );
      _fetchBuses();
      _busIdController.clear();
      _routeIdController.clear();
      _capacityController.clear();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to add bus: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        backgroundColor: Colors.blue[700],
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Add Route Section
            Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      'Add Route',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue[700],
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _routeNameController,
                      decoration: const InputDecoration(
                        labelText: 'Route Name',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.map),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _polylineController,
                      decoration: const InputDecoration(
                        labelText: 'Polyline (JSON: [{lat: x, lng: y}, ...])',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.polyline),
                      ),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _addRoute,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue[700],
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                      child: const Text('Add Route'),
                    ),
                  ],
                ),
              ),
            ),
            // Add Bus Section
            Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      'Add Bus',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue[700],
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _busIdController,
                      decoration: const InputDecoration(
                        labelText: 'Bus ID',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.directions_bus),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _routeIdController,
                      decoration: const InputDecoration(
                        labelText: 'Route ID (Optional)',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.route),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _capacityController,
                      decoration: const InputDecoration(
                        labelText: 'Capacity',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.people),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _addBus,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue[700],
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                      child: const Text('Add Bus'),
                    ),
                  ],
                ),
              ),
            ),
            // View Stops Section
            Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      'View Stops',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue[700],
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _stopRouteIdController,
                      decoration: const InputDecoration(
                        labelText: 'Route ID',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.route),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _fetchStops,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue[700],
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                      child: const Text('Load Stops'),
                    ),
                  ],
                ),
              ),
            ),
            // Map View
            Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      'Map View',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue[700],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 400,
                      child: FlutterMap(
                        options: const MapOptions(
                          initialCenter:
                              latlng.LatLng(27.7172, 85.3240), // Kathmandu
                          initialZoom: 12,
                        ),
                        children: [
                          TileLayer(
                            urlTemplate:
                                'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                            subdomains: const ['a', 'b', 'c'],
                          ),
                          PolylineLayer(polylines: _polylines),
                          MarkerLayer(markers: _markers),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _routeNameController.dispose();
    _polylineController.dispose();
    _busIdController.dispose();
    _routeIdController.dispose();
    _capacityController.dispose();
    _stopRouteIdController.dispose();
    super.dispose();
  }
}
