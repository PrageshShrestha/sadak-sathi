import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_map_cancellable_tile_provider/flutter_map_cancellable_tile_provider.dart';
import 'show_map.dart'; // Import ShowMapScreen
import 'globals.dart' as globals;

class MapScreen extends StatefulWidget {
  const MapScreen({Key? key}) : super(key: key);

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final MapController _mapController = MapController();
  final String _baseUrl = globals.baseUrl; // Replace with your server URL

  LatLng? _userLocation;
  bool _locationPermissionGranted = false;
  double _currentZoom = 13.0;

  LatLng? _startLocation;
  LatLng? _destinationLocation;
  List<LatLng> _routePoints = [];
  double? _routeDistance; // Store route distance in meters
  double? _routeDuration; // Store route duration in seconds

  final TextEditingController _searchController = TextEditingController();
  List<SearchResult> _searchResults = [];
  List<RouteData> _serverRoutes = []; // Store server-fetched routes

  static const LatLng _defaultCenter = LatLng(27.705807, 85.314227);

  @override
  void initState() {
    super.initState();
    _checkPermissionAndFetchLocation();
    _fetchServerRoutes();
  }Future<void> _fetchServerRoutes() async {
  try {
    final response = await http.post(Uri.parse('$_baseUrl/get_all_routes'), body: {});
    print('Server response status: ${response.statusCode}');
    print('Server response body: ${response.body}');
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      print('Decoded data length: ${data.length}');
      setState(() {
        _serverRoutes = data.where((route) {
          try {
            // Validate route fields
            if (route['route_id'] == null || route['route_name'] == null) {
              print('Missing route_id or route_name for route: $route');
              return false;
            }

            // Parse coordinates
            final String coordinatesStr = route['route_coordinates'] ?? '[]';
            final decodedCoordinates = json.decode(coordinatesStr);
            if (decodedCoordinates is! List || decodedCoordinates.isEmpty) {
              print('Invalid or empty coordinates for route ${route['route_id']}: $decodedCoordinates');
              return false;
            }
            final coordinates = decodedCoordinates.map((coord) {
              if (coord is! List || coord.length < 2) {
                throw FormatException('Invalid coordinate format: $coord');
              }
              final lat = coord[0] is num ? coord[0].toDouble() : double.parse(coord[0].toString());
              final lng = coord[1] is num ? coord[1].toDouble() : double.parse(coord[1].toString());
              if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
                throw FormatException('Out-of-range coordinate: [$lat, $lng]');
              }
              return LatLng(lat, lng);
            }).toList();
            if (coordinates.length < 2) {
              print('Insufficient coordinates for route ${route['route_id']}: ${coordinates.length} points');
              return false;
            }

            // Parse stops
            String stopsStr = route['route_stops'] ?? '[]';
            // Handle double-encoded JSON
            if (stopsStr.startsWith('"') && stopsStr.endsWith('"')) {
              stopsStr = stopsStr.substring(1, stopsStr.length - 1).replaceAll('\\"', '"');
            }
            List<dynamic> decodedStops;
            try {
              decodedStops = json.decode(stopsStr);
            } catch (e) {
              // Handle tuple-like string (e.g., "[ ('Panauti', ...)]")
              print('Failed to decode stops as JSON for route ${route['route_id']}: $e');
              // Convert tuple string to list of lists
              final tupleRegex = RegExp(r"\('([^']+)',\s*([\d.]+),\s*([\d.]+),\s*(\d+)\)");
              final matches = tupleRegex.allMatches(stopsStr);
              decodedStops = matches.map((match) {
                return [
                  match.group(1), // name
                  double.parse(match.group(2)!), // lat
                  double.parse(match.group(3)!), // lng
                  match.group(4), // stopTime (integer as string)
                ];
              }).toList();
              if (decodedStops.isEmpty) {
                print('No valid stops parsed from tuple string for route ${route['route_id']}');
                return false;
              }
            }

            if (decodedStops is! List) {
              print('Invalid stops format for route ${route['route_id']}: $decodedStops');
              return false;
            }
            final stops = decodedStops.map((stop) {
              if (stop is! List || stop.length < 4) {
                throw FormatException('Invalid stop format: $stop');
              }
              return Stop(
                name: stop[0] as String? ?? 'Unknown',
                lat: stop[1] is num ? stop[1].toDouble() : double.parse(stop[1].toString()),
                lng: stop[2] is num ? stop[2].toDouble() : double.parse(stop[2].toString()),
                stopTime: stop[3].toString(), // Convert integer to string
              );
            }).toList();

            print('Valid route ${route['route_id']}: ${route['route_name']} with ${coordinates.length} coordinates and ${stops.length} stops');
            return true; // Valid route
          } catch (e) {
            print('Error parsing route ${route['route_id'] ?? 'unknown'}: $e');
            return false; // Skip invalid route
          }
        }).map((route) {
          final coordinates = (json.decode(route['route_coordinates'] ?? '[]') as List)
              .map((coord) => LatLng(
                    coord[0] is num ? coord[0].toDouble() : double.parse(coord[0].toString()),
                    coord[1] is num ? coord[1].toDouble() : double.parse(coord[1].toString()),
                  ))
              .toList();
          String stopsStr = route['route_stops'] ?? '[]';
          if (stopsStr.startsWith('"') && stopsStr.endsWith('"')) {
            stopsStr = stopsStr.substring(1, stopsStr.length - 1).replaceAll('\\"', '"');
          }
          List<dynamic> decodedStops;
          try {
            decodedStops = json.decode(stopsStr);
          } catch (e) {
            // Handle tuple-like string
            final tupleRegex = RegExp(r"\('([^']+)',\s*([\d.]+),\s*([\d.]+),\s*(\d+)\)");
            final matches = tupleRegex.allMatches(stopsStr);
            decodedStops = matches.map((match) {
              return [
                match.group(1),
                double.parse(match.group(2)!),
                double.parse(match.group(3)!),
                match.group(4),
              ];
            }).toList();
          }
          final stops = decodedStops
              .map((stop) => Stop(
                    name: stop[0] as String? ?? 'Unknown',
                    lat: stop[1] is num ? stop[1].toDouble() : double.parse(stop[1].toString()),
                    lng: stop[2] is num ? stop[2].toDouble() : double.parse(stop[2].toString()),
                    stopTime: stop[3].toString(),
                  ))
              .toList();
          return RouteData(
            routeId: route['route_id'] as int,
            routeName: route['route_name'] as String,
            coordinates: coordinates,
            stops: stops,
          );
        }).toList();
        print('Total valid server routes: ${_serverRoutes.length}');
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to fetch routes: ${response.statusCode}')),
      );
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error fetching routes: $e')),
    );
  }
}
  Future<void> _checkPermissionAndFetchLocation() async {
    PermissionStatus status = await Permission.location.status;

    if (!status.isGranted) {
      status = await Permission.location.request();
      if (!status.isGranted) {
        setState(() {
          _locationPermissionGranted = false;
          _userLocation = null;
        });
        return;
      }
    }

    setState(() {
      _locationPermissionGranted = true;
    });

    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        _userLocation = LatLng(position.latitude, position.longitude);
      });

      _moveMapToUser();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error fetching location: $e')),
        );
      }
    }
  }

  void _moveMapToUser() {
    if (_userLocation != null) {
      _mapController.move(_userLocation!, _currentZoom);
    }
  }

  void _toggleLocation() async {
    if (_locationPermissionGranted) {
      setState(() {
        _locationPermissionGranted = false;
        _userLocation = null;
        _startLocation = null;
        _destinationLocation = null;
        _routePoints.clear();
        _routeDistance = null;
        _routeDuration = null;
      });
    } else {
      await _checkPermissionAndFetchLocation();
    }
  }

  Future<void> _searchPlace(String query) async {
    if (query.trim().isEmpty) {
      setState(() {
        _searchResults = [];
      });
      return;
    }

    final url =
        'https://nominatim.openstreetmap.org/search?q=${Uri.encodeComponent(query)}&format=json&limit=5';

    try {
      final response = await http.get(Uri.parse(url), headers: {
        'User-Agent': 'SadakSathiApp/1.0 (your_email@example.com)',
      });

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);

        final results = data.map((item) {
          return SearchResult(
            displayName: item['display_name'] as String,
            lat: double.parse(item['lat'] as String),
            lon: double.parse(item['lon'] as String),
          );
        }).toList();

        setState(() {
          _searchResults = results;
        });
      }
    } catch (e) {
      // Silent error handling
    }
  }

  void _selectSearchResult(SearchResult result) {
    setState(() {
      _destinationLocation = LatLng(result.lat, result.lon);
      _searchController.text = result.displayName;
      _routePoints.clear();
      _routeDistance = null;
      _routeDuration = null;
    });
    _mapController.move(_destinationLocation!, 15);

    // Show dialog with route option
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Route Options'),
          content: const Text('Would you like to get the shortest route to this location?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                setState(() {
                  _searchResults = [];
                  if (_startLocation != null) {
                    _showRoute();
                  } else if (_locationPermissionGranted && _userLocation != null) {
                    _startLocation = _userLocation;
                    _showRoute();
                  }
                });
              },
              child: const Text('Get Route'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                setState(() {
                  _searchResults = [];
                });
              },
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _showRoute() async {
    if (_startLocation == null || _destinationLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select both start and destination points'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final from = _startLocation!;
    final to = _destinationLocation!;

    final url = 'https://router.project-osrm.org/route/v1/driving/${from.longitude},${from.latitude};${to.longitude},${to.latitude}?overview=full&geometries=geojson';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        final routes = data['routes'] as List<dynamic>;
        if (routes.isNotEmpty) {
          final geometry = routes[0]['geometry'];
          final coordinates = geometry['coordinates'] as List<dynamic>;
          final distance = routes[0]['distance'] as double;
          final duration = routes[0]['duration'] as double;

          List<LatLng> points = coordinates
              .map((c) => LatLng(c[1] as double, c[0] as double))
              .toList();

          setState(() {
            _routePoints = points;
            _routeDistance = distance;
            _routeDuration = duration;
          });

          final bounds = LatLngBounds.fromPoints([...points, from, to]);
          _mapController.fitCamera(
            CameraFit.bounds(
              bounds: bounds,
              padding: const EdgeInsets.all(50),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to fetch route: ${response.statusCode}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching route: $e')),
      );
    }
  }

  Future<String> _reverseGeocode(LatLng point) async {
    final url =
        'https://nominatim.openstreetmap.org/reverse?format=json&lat=${point.latitude}&lon=${point.longitude}';

    try {
      final response = await http.get(Uri.parse(url), headers: {
        'User-Agent': 'SadakSathiApp/1.0 (your_email@example.com)',
      });

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['display_name'] as String? ?? 'Selected Location';
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error getting location name: $e')),
      );
    }
    return 'Selected Location';
  }

  void _handleLongPress(TapPosition position, LatLng point) async {
    final displayName = await _reverseGeocode(point);

    setState(() {
      if (_startLocation == null) {
        _startLocation = point;
        _searchController.text = 'Start: $displayName';
      } else if (_destinationLocation == null) {
        _destinationLocation = point;
        _searchController.text = 'Destination: $displayName';
      } else {
        // Replace destination if both points are set
        _destinationLocation = point;
        _searchController.text = 'Destination: $displayName';
      }
      _searchResults = [];
      _routePoints.clear();
      _routeDistance = null;
      _routeDuration = null;
    });
    _mapController.move(point, 15);

    // Automatically calculate route if both points are set
    if (_startLocation != null && _destinationLocation != null) {
      _showRoute();
    }
  }

  void _handleTap(TapPosition position, LatLng point) {
    // Check if tap is near any server route
    const double proximityThreshold = 100; // meters
    final distance = const Distance();

    for (final route in _serverRoutes) {
      for (final coord in route.coordinates) {
        final dist = distance(point, coord);
        if (dist < proximityThreshold) {
          // Show dialog to redirect to ShowMapScreen
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Route: ${route.routeName}'),
                content: Text('Would you like to view details for ${route.routeName}?'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ShowMapScreen(
                            routeId: route.routeId,
                            routeName: route.routeName,
                          ),
                        ),
                      );
                    },
                    child: const Text('Yes'),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('No'),
                  ),
                ],
              );
            },
          );
          return; // Exit after finding the first nearby route
        }
      }
    }
  }

  void _handleRightClick(TapPosition position, LatLng point) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_locationPermissionGranted && _userLocation != null)
                ListTile(
                  leading: const Icon(Icons.my_location, color: Colors.blue),
                  title: const Text('Get Route from My Location'),
                  onTap: () async {
                    Navigator.pop(context);
                    final displayName = await _reverseGeocode(point);
                    setState(() {
                      _startLocation = _userLocation;
                      _destinationLocation = point;
                      _searchController.text = 'Destination: $displayName';
                      _searchResults = [];
                      _routePoints.clear();
                      _routeDistance = null;
                      _routeDuration = null;
                    });
                    _showRoute();
                  },
                ),
              ListTile(
                leading: const Icon(Icons.trip_origin, color: Colors.blue),
                title: const Text('Set as Start Point'),
                onTap: () async {
                  Navigator.pop(context);
                  final displayName = await _reverseGeocode(point);
                  setState(() {
                    _startLocation = point;
                    _searchController.text = 'Start: $displayName';
                    _searchResults = [];
                    _routePoints.clear();
                    _routeDistance = null;
                    _routeDuration = null;
                  });
                  _mapController.move(point, 15);
                  if (_startLocation != null && _destinationLocation != null) {
                    _showRoute();
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.location_on, color: Colors.red),
                title: const Text('Set as Destination'),
                onTap: () async {
                  Navigator.pop(context);
                  final displayName = await _reverseGeocode(point);
                  setState(() {
                    _destinationLocation = point;
                    _searchController.text = 'Destination: $displayName';
                    _searchResults = [];
                    _routePoints.clear();
                    _routeDistance = null;
                    _routeDuration = null;
                  });
                  _mapController.move(point, 15);
                  if (_startLocation != null && _destinationLocation != null) {
                    _showRoute();
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.clear, color: Colors.grey),
                title: const Text('Clear Points'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _startLocation = null;
                    _destinationLocation = null;
                    _searchController.clear();
                    _searchResults = [];
                    _routePoints.clear();
                    _routeDistance = null;
                    _routeDuration = null;
                  });
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sadak Sathi Map'),
        backgroundColor: Colors.green.shade700,
        foregroundColor: Colors.white,
        elevation: 2,
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Search bar
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Container(
                  width: isMobile ? double.infinity : 400,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search, color: Colors.green),
                      hintText: 'Search a place',
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          setState(() {
                            _searchController.clear();
                            _searchResults = [];
                            _startLocation = null;
                            _destinationLocation = null;
                            _routePoints.clear();
                            _routeDistance = null;
                            _routeDuration = null;
                          });
                        },
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                    onChanged: _searchPlace,
                  ),
                ),
              ),

              // Search results or map
              if (_searchResults.isNotEmpty)
                Expanded(
                  child: Container(
                    color: Colors.white,
                    child: ListView.builder(
                      itemCount: _searchResults.length,
                      itemBuilder: (context, index) {
                        final result = _searchResults[index];
                        return ListTile(
                          leading: const Icon(Icons.location_on, color: Colors.red),
                          title: Text(
                            result.displayName,
                            style: const TextStyle(fontSize: 16),
                          ),
                          onTap: () {
                            _selectSearchResult(result);
                            FocusScope.of(context).unfocus();
                          },
                        );
                      },
                    ),
                  ),
                )
              else
                Expanded(
                  child: Stack(
                    children: [
                      FlutterMap(
                        mapController: _mapController,
                        options: MapOptions(
                          initialCenter: _userLocation ?? _defaultCenter,
                          initialZoom: _currentZoom,
                          maxZoom: 19.0,
                          minZoom: 3.0,
                          onPositionChanged: (pos, _) {
                            setState(() {
                              _currentZoom = pos.zoom ?? _currentZoom;
                            });
                          },
                          onLongPress: _handleLongPress,
                          onSecondaryTap: _handleRightClick,
                          onTap: _handleTap,
                        ),
                        children: [
                          TileLayer(
                            urlTemplate:
                                'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                            subdomains: const ['a', 'b', 'c'],
                            tileProvider: CancellableNetworkTileProvider(),
                            userAgentPackageName: 'com.example.sadak_sathi',
                          ),
                          // Server routes
                          PolylineLayer(
                            polylines: _serverRoutes
                                .map((route) => Polyline(
                                      points: route.coordinates,
                                      strokeWidth: 3.0,
                                      color: Colors.purple.withOpacity(0.7),
                                    ))
                                .toList(),
                          ),
                          // Server stops
                          MarkerLayer(
                            markers: _serverRoutes
                                .expand((route) => route.stops
                                    .map((stop) => Marker(
                                          point: LatLng(stop.lat, stop.lng),
                                          width: 30,
                                          height: 30,
                                          child: GestureDetector(
                                            onTap: () {
                                              showDialog(
                                                context: context,
                                                builder: (BuildContext context) {
                                                  return AlertDialog(
                                                    title: Text('Stop: ${stop.name}'),
                                                    content: Text('View route ${route.routeName}?'),
                                                    actions: [
                                                      TextButton(
                                                        onPressed: () {
                                                          Navigator.pop(context);
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) => ShowMapScreen(
                                                                routeId: route.routeId,
                                                                routeName: route.routeName,
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                        child: const Text('Yes'),
                                                      ),
                                                      TextButton(
                                                        onPressed: () {
                                                          Navigator.pop(context);
                                                        },
                                                        child: const Text('No'),
                                                      ),
                                                    ],
                                                  );
                                                },
                                              );
                                            },
                                            child: const Icon(
                                              Icons.stop_circle,
                                              color: Colors.orange,
                                              size: 30,
                                            ),
                                          ),
                                        )))
                                .toList(),
                          ),
                          // User route
                          if (_routePoints.isNotEmpty)
                            PolylineLayer(
                              polylines: [
                                Polyline(
                                  points: _routePoints,
                                  strokeWidth: 4.0,
                                  color: Colors.blueAccent,
                                ),
                              ],
                            ),
                          MarkerLayer(
                            markers: [
                              if (_locationPermissionGranted && _userLocation != null)
                                Marker(
                                  point: _userLocation!,
                                  width: 40,
                                  height: 40,
                                  child: const Icon(
                                    Icons.my_location,
                                    color: Colors.blue,
                                    size: 40,
                                  ),
                                ),
                              if (_startLocation != null)
                                Marker(
                                  point: _startLocation!,
                                  width: 40,
                                  height: 40,
                                  child: const Icon(
                                    Icons.trip_origin,
                                    color: Colors.blue,
                                    size: 40,
                                  ),
                                ),
                              if (_destinationLocation != null)
                                Marker(
                                  point: _destinationLocation!,
                                  width: 40,
                                  height: 40,
                                  child: const Icon(
                                    Icons.location_on,
                                    color: Colors.red,
                                    size: 40,
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

              // Route info card
              if (_routePoints.isNotEmpty && _routeDistance != null && _routeDuration != null)
                Container(
                  margin: const EdgeInsets.all(12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Distance: ${(_routeDistance! / 1000).toStringAsFixed(1)} km',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      Text(
                        'Time: ${(_routeDuration! / 60).toStringAsFixed(0)} min',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),

          // Floating buttons
          Positioned(
            bottom: 16,
            right: 16,
            child: Column(
              children: [
                FloatingActionButton(
                  heroTag: 'location_toggle',
                  backgroundColor: _locationPermissionGranted ? Colors.green.shade600 : Colors.grey.shade600,
                  onPressed: _toggleLocation,
                  tooltip: _locationPermissionGranted ? 'Disable Location' : 'Enable Location',
                  child: Icon(
                    _locationPermissionGranted ? Icons.gps_fixed : Icons.gps_off,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SearchResult {
  final String displayName;
  final double lat;
  final double lon;

  SearchResult({
    required this.displayName,
    required this.lat,
    required this.lon,
  });
}

class RouteData {
  final int routeId;
  final String routeName;
  final List<LatLng> coordinates;
  final List<Stop> stops;

  RouteData({
    required this.routeId,
    required this.routeName,
    required this.coordinates,
    required this.stops,
  });
}

class Stop {
  final String name;
  final double lat;
  final double lng;
  final String stopTime;

  Stop({
    required this.name,
    required this.lat,
    required this.lng,
    required this.stopTime,
  });
}