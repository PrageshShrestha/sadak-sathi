// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/custom_button.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWeb = constraints.maxWidth > 600;
        final padding = EdgeInsets.symmetric(
          horizontal:
              isWeb ? constraints.maxWidth * 0.1 : constraints.maxWidth * 0.05,
          vertical: 20,
        );
        final fontSizeTitle = isWeb ? 40.0 : 32.0;
        final fontSizeTagline = isWeb ? 22.0 : 18.0;

        return Scaffold(
          appBar: AppBar(
            title: const Text('Sadak Sathi'),
            actions: [
              IconButton(
                icon: const Icon(Icons.logout),
                onPressed: () {
                  Provider.of<AuthProvider>(context, listen: false).logout();
                  Navigator.pushReplacementNamed(context, '/login');
                },
              ),
            ],
          ),
          body: Stack(
            children: [
              Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/map_background.jpg'),
                    fit: BoxFit.cover,
                    colorFilter: ColorFilter.mode(
                      Colors.black26,
                      BlendMode.darken,
                    ),
                  ),
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight,
                ),
                child: Center(
                  child: Padding(
                    padding: padding,
                    child: Card(
                      elevation: 8,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      color: Colors.white.withOpacity(0.9),
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const SizedBox(height: 20),
                            Image.asset(
                              'assets/images/bus.png',
                              height: isWeb ? 180 : 150,
                            )
                                .animate()
                                .fadeIn(duration: 500.ms)
                                .scale(duration: 600.ms, curve: Curves.easeOut)
                                .then()
                                .moveY(
                                  begin: -15,
                                  end: 0,
                                  duration: 400.ms,
                                  curve: Curves.bounceOut,
                                ),
                            const SizedBox(height: 20),
                            Text(
                              'Sadak-Sathi',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: fontSizeTitle,
                                fontWeight: FontWeight.bold,
                                color: Colors.green[900],
                                shadows: const [
                                  Shadow(
                                    color: Colors.black26,
                                    offset: Offset(2, 2),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            )
                                .animate()
                                .fadeIn(duration: 600.ms)
                                .slideX(begin: -0.2, end: 0),
                            const SizedBox(height: 10),
                            Text(
                              'Track your bus in real-time',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: fontSizeTagline,
                                color: Colors.black54.withOpacity(0.9),
                              ),
                            )
                                .animate()
                                .fadeIn(duration: 700.ms)
                                .slideX(begin: 0.2, end: 0),
                            const SizedBox(height: 40),
                            CustomButton(
                              text: 'Login/Signup',
                              icon: Icons.map,
                              onPressed: () =>
                                  Navigator.pushNamed(context, '/login'),
                              backgroundColor: Colors.white,
                              textColor: Colors.green,
                            ),
                            const SizedBox(height: 20),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: CustomButton(
                                    text: 'Select Route',
                                    icon: Icons.list,
                                    onPressed: () =>
                                        Navigator.pushNamed(context, '/routes_show'),
                                    backgroundColor: Colors.green,
                                    textColor: Colors.white,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: CustomButton(
                                    text: 'See live map',
                                    icon: Icons.settings,
                                    onPressed: () => Navigator.pushNamed(
                                        context, '/map'),
                                    backgroundColor: Colors.green,
                                    textColor: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                            
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              if (isWeb)
                const Positioned(
                  left: 0,
                  right: 0,
                  bottom: 20,
                  child: Center(
                    child: Text(
                      'Sadak-Sathi v1.0 | © 2025',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
