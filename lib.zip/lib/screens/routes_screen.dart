// lib/screens/routes_screen.dart
import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'show_map.dart';

class RoutesScreen extends StatefulWidget {
  const RoutesScreen({Key? key}) : super(key: key);

  @override
  State<RoutesScreen> createState() => _RoutesScreenState();
}

class _RoutesScreenState extends State<RoutesScreen> {
  late Future<List<Map<String, dynamic>>> _routesFuture;
  List<Map<String, dynamic>> _allRoutes = [];
  List<Map<String, dynamic>> _filteredRoutes = [];
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _routesFuture = ApiService().getRoutes();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase().trim();
    if (query.isEmpty) {
      setState(() {
        _filteredRoutes = List.from(_allRoutes);
      });
    } else {
      List<Map<String, dynamic>> matches = [];

      for (var route in _allRoutes) {
        final routeName = (route['route_name'] ?? '').toString().toLowerCase();
        final routeId = (route['route_id'] ?? '').toString().toLowerCase();

        if (routeName.contains(query) || routeId.contains(query)) {
          matches.add(route);
        }
      }

      // Sort matches: exact prefix matches first
      matches.sort((a, b) {
        final aName = (a['route_name'] ?? '').toString().toLowerCase();
        final bName = (b['route_name'] ?? '').toString().toLowerCase();

        final aStarts = aName.startsWith(query) ? 0 : 1;
        final bStarts = bName.startsWith(query) ? 0 : 1;
        return aStarts.compareTo(bStarts);
      });

      setState(() {
        _filteredRoutes = matches;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Route')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _routesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No routes available'));
          }

          if (_allRoutes.isEmpty) {
            // Cache the routes once
            _allRoutes = snapshot.data!;
            _filteredRoutes = List.from(_allRoutes);
          }

          return Column(
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search by route name or ID',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                            },
                          )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                  ),
                ),
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _filteredRoutes.length,
                  separatorBuilder: (context, index) => const Divider(),
                  itemBuilder: (context, index) {
                    final route = _filteredRoutes[index];
                    final routeName = route['route_name'] ?? 'Unnamed Route';
                    final routeId = route['route_id'] ?? 0;

                    return ListTile(
                      title: Text(routeName),
                      subtitle: Text('ID: $routeId'),
                      trailing: const Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ShowMapScreen(
                              routeId: routeId,
                              routeName: routeName,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
