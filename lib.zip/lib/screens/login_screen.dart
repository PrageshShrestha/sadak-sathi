import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _adminTokenController = TextEditingController();
  final _busNumberController = TextEditingController();
  final _busPasswordController = TextEditingController();

  bool _isAdmin = false;
  bool _isBus = false;
  bool _isLoading = false;
  final ApiService _apiService = ApiService();

  Future<void> _login() async {
    if (_isBus) {
      if (_busNumberController.text.isEmpty ||
          _busPasswordController.text.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill in all fields')),
        );
        return;
      }

      setState(() => _isLoading = true);
      try {
        await _apiService.busLogin(
          context,
          _busNumberController.text,
          _busPasswordController.text,
        );
        debugPrint("✅ Bus login successful");

        Provider.of<AuthProvider>(context, listen: false).login("bus-session", 'bus');
        // Updated navigation here to /bus_infos with arguments
        Navigator.pushReplacementNamed(
          context,
          '/bus_infos',
          arguments: {
            'busNumber': _busNumberController.text,
            'routeId': 0,      // Replace with actual routeId if available
            'routeName': '',   // Replace with actual routeName if available
          },
        );
      } catch (e) {
        debugPrint("❌ Bus login error: $e");
        String errorMessage = 'Bus login failed: $e';
        if (e.toString().contains('401')) {
          errorMessage = 'Unauthorized. Please check bus credentials.';
        }
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorMessage)),
        );
      } finally {
        setState(() => _isLoading = false);
      }
      return;
    }

    if (_emailController.text.isEmpty ||
        _passwordController.text.isEmpty ||
        (_isAdmin && _adminTokenController.text.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    if (!EmailValidator.validate(_emailController.text)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid email address')),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      Map<String, dynamic> response;
      String role;
      if (_isAdmin) {
        response = await _apiService.adminLogin(
          _emailController.text,
          _passwordController.text,
          _adminTokenController.text,
        );
        role = 'admin';
      } else {
        response = await _apiService.login(
          _emailController.text,
          _passwordController.text,
        );
        role = 'user';
      }
      final token = response['access_token'];
      debugPrint("✅ $role login successful, token: $token");

      Provider.of<AuthProvider>(context, listen: false).login(token, role);
      Navigator.pushReplacementNamed(
        context,
        role == 'admin' ? '/admin_panel' : '/home',
      );
    } catch (e) {
      debugPrint("❌ Login error: $e");

      String errorMessage = 'Login failed: $e';
      if (e.toString().contains('422')) {
        errorMessage = 'Invalid input. Check all fields.';
      } else if (e.toString().contains('400')) {
        errorMessage = 'Invalid admin credentials.';
      } else if (e.toString().contains('401')) {
        errorMessage = 'Unauthorized. Check credentials.';
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _resendAdminToken() async {
    if (_emailController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter an email address')),
      );
      return;
    }

    if (!EmailValidator.validate(_emailController.text)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid email address')),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      final response =
          await _apiService.requestAdminToken(_emailController.text);
      debugPrint("✅ Admin token response: $response");

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(response['message'] +
                (response.containsKey('token')
                    ? ': ${response['token']}'
                    : ''))),
      );
      if (response.containsKey('token')) {
        _adminTokenController.text = response['token'];
      }
    } catch (e) {
      debugPrint("❌ Failed to request admin token: $e");

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to resend token: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Card(
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Sadak Sathi',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.green[700],
                    ),
                  ),
                  const SizedBox(height: 20),

                  if (!_isBus) ...[
                    TextField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.email),
                      ),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _passwordController,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.lock),
                      ),
                      obscureText: true,
                    ),
                  ],

                  if (_isAdmin && !_isBus) ...[
                    const SizedBox(height: 16),
                    TextField(
                      controller: _adminTokenController,
                      decoration: InputDecoration(
                        labelText: 'Admin Token',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.vpn_key),
                      ),
                      obscureText: true,
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: _isLoading ? null : _resendAdminToken,
                      child: Text(
                        'Resend Admin Token',
                        style: TextStyle(color: Colors.green[700]),
                      ),
                    ),
                  ],

                  if (_isBus) ...[
                    TextField(
                      controller: _busNumberController,
                      decoration: InputDecoration(
                        labelText: 'Bus Number',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.directions_bus),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _busPasswordController,
                      decoration: InputDecoration(
                        labelText: 'Bus Password',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.lock),
                      ),
                      obscureText: true,
                    ),
                  ],

                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Admin Login'),
                      Switch(
                        value: _isAdmin,
                        onChanged: (value) {
                          setState(() {
                            _isAdmin = value;
                            if (value) _isBus = false;
                          });
                        },
                      ),
                      const Text('Bus Login'),
                      Switch(
                        value: _isBus,
                        onChanged: (value) {
                          setState(() {
                            _isBus = value;
                            if (value) _isAdmin = false;
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _isLoadingButton(),
                  if (!_isBus) ...[
                    TextButton(
                      onPressed: () =>
                          Navigator.pushNamed(context, '/register'),
                      child: Text(
                        'Don\'t have an account? Register',
                        style: TextStyle(color: Colors.green[700]),
                      ),
                    ),
                    TextButton(
                      onPressed: () =>
                          Navigator.pushNamed(context, '/admin_register'),
                      child: Text(
                        'Register as Admin',
                        style: TextStyle(color: Colors.green[700]),
                      ),
                    ),
                  ]
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _isLoadingButton() {
    return _isLoading
        ? const CircularProgressIndicator()
        : ElevatedButton(
            onPressed: _login,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green[700],
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Login'),
          );
  }
}
