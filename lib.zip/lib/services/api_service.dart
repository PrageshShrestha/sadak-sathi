import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import '../screens/globals.dart' as globals;

class ApiService {
  final String? token;
  static const String baseUrl = globals.baseUrl;

  ApiService({this.token});

  Future<Map<String, dynamic>> register(
      String name, String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'name': name, 'email': email, 'password': password}),
      );
      print('Register response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception(
            'Failed to register: ${errorDetails is List ? errorDetails[0]['msg'] : errorDetails}');
      }
    } catch (e) {
      print('Register error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> requestAdminToken(String email) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/request-admin-token'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email}),
      );
      print(
          'Request admin token response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception(
            'Failed to request admin token: ${errorDetails is List ? errorDetails[0]['msg'] : errorDetails}');
      }
    } catch (e) {
      print('Request admin token error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> adminRegister(
      String name, String email, String password, String adminToken) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/admin/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
          'admin_token': adminToken,
        }),
      );
      print('Admin register response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception(
            'Failed to register admin: ${errorDetails is List ? errorDetails[0]['msg'] : errorDetails}');
      }
    } catch (e) {
      print('Admin register error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/token'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'username': email,
          'password': password,
        },
      );
      print('Login response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception('Failed to login: $errorDetails');
      }
    } catch (e) {
      print('Login error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> adminLogin(
      String email, String password, String token) async {
    try {
      final requestBody = {
        'email': email,
        'password': password,
        'token': token
      };
      print('Admin login request: $requestBody');
      final response = await http.post(
        Uri.parse('$baseUrl/admin/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(requestBody),
      );
      print('Admin login response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception(
            'Failed to login as admin: ${errorDetails is List ? errorDetails[0]['msg'] : errorDetails}');
      }
    } catch (e) {
      print('Admin login error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> addRoute(
      String name, List<Map<String, double>> polyline) async {
    try {
      if (token == null) {
        throw Exception('Authentication token is required');
      }
      final response = await http.post(
        Uri.parse('$baseUrl/routes'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'name': name,
          'polyline': polyline,
        }),
      );
      print('Add route response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception(
            'Failed to add route: ${errorDetails is List ? errorDetails[0]['msg'] : errorDetails}');
      }
    } catch (e) {
      print('Add route error: $e');
      rethrow;
    }
  }

  Future<List<Map<String, dynamic>>> getRoutes() async {
    final response = await http.post(Uri.parse('$baseUrl/')); // Adjust if needed

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      final data = json.decode(response.body);

      if (data['route_data'] == null) {
        throw Exception('Key "routes" not found in response');
      }

      List routesList = data['route_data'];
      return List<Map<String, dynamic>>.from(routesList);
    } else {
      throw Exception('Failed to load routes');
    }
  }

  Future<List<Map<String, dynamic>>> getBuses() async {
    try {
      if (token == null) {
        throw Exception('Authentication token is required');
      }
      final response = await http.get(
        Uri.parse('$baseUrl/buses'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );
      print('Get buses response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(jsonDecode(response.body));
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception('Failed to fetch buses: $errorDetails');
      }
    } catch (e) {
      print('Get buses error: $e');
      rethrow;
    }
  }

  Future<List<Map<String, dynamic>>> getStops(int routeId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/stops?route_id=$routeId'),
        headers: {'Content-Type': 'application/json'},
      );
      print('Get stops response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(jsonDecode(response.body));
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception('Failed to fetch stops: $errorDetails');
      }
    } catch (e) {
      print('Get stops error: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>> addBus(
      String busId, int? routeId, int capacity) async {
    try {
      if (token == null) {
        throw Exception('Authentication token is required');
      }
      final response = await http.post(
        Uri.parse('$baseUrl/buses'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'bus_id': busId,
          'route_id': routeId,
          'capacity': capacity,
        }),
      );
      print('Add bus response: ${response.statusCode} ${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception(
            'Failed to add bus: ${errorDetails is List ? errorDetails[0]['msg'] : errorDetails}');
      }
    } catch (e) {
      print('Add bus error: $e');
      rethrow;
    }
  }

 Future<Map<String, dynamic>> busLogin(BuildContext context, String busNumber, String password) async {
  try {
    final response = await http.post(
      Uri.parse('$baseUrl/bus_login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'bus_number': busNumber,
        'password': password,
      }),
    );

    print('Bus login response: ${response.statusCode} ${response.body}');
    final data = jsonDecode(response.body);

    if (response.statusCode == 200 || data['status_code'] == 200) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('bus_number', busNumber);
      return data; // ✅ return response map
    } else {
      throw Exception(data['message'] ?? 'Failed to login bus');
    }
  } catch (e) {
    print('Bus login error: $e');
    rethrow;
  }
}

  // ✅ NEW: Fetch Bus Info by Bus Number
  Future<Map<String, dynamic>> fetchBusInfo(String busNumber) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/bus_infos/$busNumber'));
      print('Bus info response: ${response.statusCode} ${response.body}');

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        final errorDetails = jsonDecode(response.body)['detail'];
        throw Exception('Failed to fetch bus info: $errorDetails');
      }
    } catch (e) {
      print('Fetch bus info error: $e');
      rethrow;
    }
  }
}
