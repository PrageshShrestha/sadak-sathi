// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/admin_register_screen.dart';
import 'screens/home_screen.dart';
import 'screens/map_screen.dart';
import 'screens/routes_screen.dart';  // <-- import the real RoutesScreen here
import 'screens/admin_panel.dart';
import 'providers/auth_provider.dart';
import 'providers/bus_provider.dart';
import 'screens/show_map.dart';
import "screens/admin_1.dart";
import "screens/admin_2.dart";
import "screens/busdash.dart";
import "screens/admin_data.dart";
// Import the bus_profile screen here (you need to create it)

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => BusProvider()),
      ],
      child: const SadakSathiApp(),
    ),
  );
}

class SadakSathiApp extends StatelessWidget {
  const SadakSathiApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sadak Sathi',
      theme: ThemeData(
        primarySwatch: Colors.green,
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.grey[100],
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.green[700],
          foregroundColor: Colors.white,
        ),
      ),
      initialRoute: '/home',
      routes: {
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/admin_register': (context) => AdminRegisterScreen(),
        '/home': (context) => const HomeScreen(),
        '/map': (context) => const MapScreen(),
        '/admin_panel': (context) => AdminDataPanel(),

        // Added /bus_profile route here
        

        // Updated bus_infos route to accept arguments and pass to BusMapScreen
        '/bus_infos': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;

          if (args == null) {
            // If no args provided, you can return some fallback widget or error
            return Scaffold(
              appBar: AppBar(title: const Text('Error')),
              body: const Center(child: Text('Missing bus info parameters')),
            );
          }

          return BusMapScreen(
            initialBusNumber: args['busNumber'] ?? '',
            initialRouteId: args['routeId'] ?? 0,
            initialRouteName: args['routeName'] ?? '',
          );
        },

        //'/admin_panel':(context)=>AdminLoginScreen(),
        '/routes_show': (context) => const RoutesScreen(),  // <-- real RoutesScreen here
        '/settings': (context) => const SettingsScreen(),
        '/admin_1': (context) => const AddRouteScreen(),
        '/admin_2': (context) => const AddBusScreen(),
        '/personal_info': (context) => const PersonalInfoScreen(), // New route for personal info
        // '/show_map': (context) => ShowMapScreen(...),
      },
    );
  }
}

class AdminPanelScreen extends StatelessWidget {
  const AdminPanelScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Panel')),
      body: const Center(child: Text('Admin Panel (Placeholder)')),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              elevation: 2,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                leading: const Icon(Icons.lock),
                title: const Text('Change Password'),
                onTap: () {
                  _showChangePasswordDialog(context);
                },
              ),
            ),
            Card(
              elevation: 2,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                leading: const Icon(Icons.person),
                title: const Text('See Personal Info'),
                onTap: () {
                  Navigator.pushNamed(context, '/personal_info');
                },
              ),
            ),
            // Add other settings options here if needed
          ],
        ),
      ),
    );
  }

  void _showChangePasswordDialog(BuildContext context) {
    TextEditingController oldPasswordController = TextEditingController();
    TextEditingController newPasswordController = TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Change Password'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: oldPasswordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Previous Password',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: newPasswordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'New Password',
                  border: OutlineInputBorder(),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    // Handle forgot password logic here
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Forgot Password logic initiated!')),
                    );
                    Navigator.pop(context); // Close the dialog
                  },
                  child: const Text('Forgot Password?'),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            ElevatedButton(
              child: const Text('Change'),
              onPressed: () {
                // Implement password change logic here
                // You would typically call an authentication provider method
                String oldPassword = oldPasswordController.text;
                String newPassword = newPasswordController.text;
                print('Old Password: $oldPassword, New Password: $newPassword');
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Password change attempt! (Actual logic not implemented)')),
                );
                Navigator.pop(context); // Close the dialog
              },
            ),
          ],
        );
      },
    );
  }
}

class PersonalInfoScreen extends StatelessWidget {
  const PersonalInfoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // In a real app, you would fetch user info from your AuthProvider
    // For demonstration, we'll use placeholder data.
    final String userEmail = 'user@example.com';
    final String userName = 'John Doe';

    return Scaffold(
      appBar: AppBar(title: const Text('Personal Information')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 2,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Email:',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      userEmail,
                      style: const TextStyle(fontSize: 18),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Username:',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      userName,
                      style: const TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
            // You can add more personal info fields here if needed
          ],
        ),
      ),
    );
  }
}


// Add a simple BusProfileScreen if you don't have one yet
class BusProfileScreen extends StatelessWidget {
  const BusProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: Implement your bus profile UI here
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bus Profile'),
      ),
      body: const Center(
        child: Text('Welcome to the Bus Profile Screen'),
      ),
    );
  }
}
