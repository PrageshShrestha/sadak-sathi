import 'package:flutter/material.dart';
import '../models/bus.dart';

class BusProvider with ChangeNotifier {
  List<Bus> _buses = [];

  List<Bus> get buses => _buses;

  void updateBuses(List<Bus> buses) {
    _buses = buses;
    notifyListeners();
  }
}
