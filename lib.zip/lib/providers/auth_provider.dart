// lib/providers/authprovider.dart (assumed)
import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  String? _token;
  String? _role;

  String? get token => _token;
  String? get role => _role;

  void login(String token, String role) {
    _token = token;
    _role = role;
    notifyListeners();
  }

  void logout() {
    _token = null;
    _role = null;
    notifyListeners();
  }
}
